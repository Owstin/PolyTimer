# PolyTimer
An open source cube timer

Space starts and stops the timer

Backspace deletes your last solve



Submit feature requests through the issues tab